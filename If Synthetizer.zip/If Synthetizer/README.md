
# csoundSynthesizer Homework

Basic Synthesizer featuring various waveforms and a Moog Ladder filter using CSound API and Swift
